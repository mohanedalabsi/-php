<?php
require 'db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        // تشفير كلمة المرور باستخدام BCRYPT
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->execute([$username, $hashed_password]);
            $message = "تم إنشاء الحساب بنجاح! <a href='login.php'>سجل دخولك هنا</a>";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $message = "اسم المستخدم موجود مسبقاً.";
            } else {
                $message = "حدث خطأ: " . $e->getMessage();
            }
        }
    } else {
        $message = "يرجى ملء جميع الحقول.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إنشاء حساب جديد</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>إنشاء حساب جديد</h2>
        <?php if($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="اسم المستخدم" required>
            <input type="password" name="password" placeholder="كلمة المرور" required>
            <button type="submit">تسجيل</button>
        </form>
        <p>لديك حساب؟ <a href="login.php">سجل دخولك</a></p>
    </div>
</body>
</html>
