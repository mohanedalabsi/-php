# تقرير مشروع أمن الويب

## المقدمة

يهدف هذا التقرير إلى توثيق مشروع أمن الويب الذي تم تطويره باستخدام PHP و PDO، مع التركيز على تنفيذ صفحات تسجيل الدخول وإنشاء الحساب والصفحة الرئيسية بشكل آمن. يتضمن المشروع ربط قاعدة بيانات MySQL وتخزين كلمات المرور مشفرة باستخدام دوال الـ Hash. كما يتناول التقرير نتائج فحص الاختراق الذي تم إجراؤه باستخدام أدوات Kali Linux (Nmap و SQLMap) لإثبات فعالية الإجراءات الأمنية المتخذة.

## هيكل المشروع والملفات

يتكون المشروع من الملفات التالية:

- `db.php`: ملف الاتصال بقاعدة البيانات.
- `register.php`: صفحة إنشاء حساب جديد.
- `login.php`: صفحة تسجيل الدخول.
- `home.php`: الصفحة الرئيسية المحمية.
- `logout.php`: صفحة تسجيل الخروج.
- `style.css`: ملف التنسيقات (CSS).
- `setup_db.sql`: ملف SQL لإنشاء قاعدة البيانات والجداول.

## تفاصيل التنفيذ

### 1. إعداد قاعدة البيانات (`setup_db.sql`)

تم إنشاء قاعدة بيانات باسم `web_security` وجدول `users` لتخزين معلومات المستخدمين. يتميز الجدول بحقل `password` الذي يستوعب كلمات المرور المشفرة.

```sql
CREATE DATABASE IF NOT EXISTS web_security;
USE web_security;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. الاتصال بقاعدة البيانات (`db.php`)

يستخدم هذا الملف PDO للاتصال بقاعدة بيانات MySQL، مما يوفر طبقة أمان ضد هجمات حقن SQL من خلال استخدام الـ Prepared Statements.

```php
<?php
$host = 'localhost';
$db   = 'web_security';
$user = 'webuser';
$pass = 'password123'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     die("Connection failed: " . $e->getMessage());
}
?>
```

### 3. صفحة إنشاء حساب (`register.php`)

تسمح هذه الصفحة للمستخدمين بإنشاء حسابات جديدة. يتم تشفير كلمات المرور باستخدام `password_hash()` قبل تخزينها في قاعدة البيانات، مما يحميها من الكشف في حالة اختراق قاعدة البيانات.

```php
<?php
require 'db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->execute([$username, $hashed_password]);
            $message = "تم إنشاء الحساب بنجاح! <a href='login.php'>سجل دخولك هنا</a>";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $message = "اسم المستخدم موجود مسبقاً.";
            } else {
                $message = "حدث خطأ: " . $e->getMessage();
            }
        }
    } else {
        $message = "يرجى ملء جميع الحقول.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إنشاء حساب جديد</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>إنشاء حساب جديد</h2>
        <?php if($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="اسم المستخدم" required>
            <input type="password" name="password" placeholder="كلمة المرور" required>
            <button type="submit">تسجيل</button>
        </form>
        <p>لديك حساب؟ <a href="login.php">سجل دخولك</a></p>
    </div>
</body>
</html>
```

**لقطة شاشة لصفحة إنشاء الحساب:**

![صفحة إنشاء الحساب](screenshots/register_page.webp)

### 4. صفحة تسجيل الدخول (`login.php`)

تتحقق هذه الصفحة من بيانات اعتماد المستخدم. يتم استخدام `password_verify()` لمقارنة كلمة المرور المدخلة مع الـ Hash المخزن في قاعدة البيانات. يتم إنشاء جلسة (Session) للمستخدم عند تسجيل الدخول بنجاح.

```php
<?php
session_start();
require 'db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header("Location: home.php");
        exit;
    } else {
        $message = "اسم المستخدم أو كلمة المرور غير صحيحة.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>تسجيل الدخول</h2>
        <?php if($message): ?>
            <p class="error"><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="اسم المستخدم" required>
            <input type="password" name="password" placeholder="كلمة المرور" required>
            <button type="submit">دخول</button>
        </form>
        <p>ليس لديك حساب؟ <a href="register.php">أنشئ حساباً جديداً</a></p>
    </div>
</body>
</html>
```

**لقطة شاشة لصفحة تسجيل الدخول:**

![صفحة تسجيل الدخول](screenshots/login_page.webp)

### 5. الصفحة الرئيسية (`home.php`)

هذه الصفحة محمية وتتطلب تسجيل الدخول للوصول إليها. تعرض اسم المستخدم وتفاصيل حول الإجراءات الأمنية المطبقة في المشروع.

```php
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الصفحة الرئيسية</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>مرحباً بك، <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p>لقد قمت بتسجيل الدخول بنجاح إلى نظام أمن الويب.</p>
        <div class="info-box">
            <h3>تفاصيل التكليف المنفذة:</h3>
            <ul>
                <li>استخدام **PDO** للاتصال بقاعدة البيانات.</li>
                <li>تشفير كلمات المرور باستخدام **password_hash**.</li>
                <li>حماية الجلسات (Sessions).</li>
                <li>منع هجمات SQL Injection عبر Prepared Statements.</li>
            </ul>
        </div>
        <a href="logout.php" class="logout-btn">تسجيل الخروج</a>
    </div>
</body>
</html>
```

**لقطة شاشة للصفحة الرئيسية:**

![الصفحة الرئيسية](screenshots/home_page.webp)

### 6. تسجيل الخروج (`logout.php`)

يقوم هذا الملف بإنهاء جلسة المستخدم وإعادة توجيهه إلى صفحة تسجيل الدخول.

```php
<?php
session_start();
session_destroy();
header("Location: login.php");
exit;
?>
```

### 7. التنسيقات (`style.css`)

ملف CSS بسيط لتوفير مظهر جذاب للصفحات.

```css
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f4f7f6;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.container {
    background: #fff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
}

h1, h2 { color: #333; }

input {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #28a745;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

button:hover { background-color: #218838; }

.message { color: green; margin-bottom: 10px; }
.error { color: red; margin-bottom: 10px; }

.info-box {
    text-align: right;
    background: #e9ecef;
    padding: 15px;
    border-radius: 5px;
    margin: 20px 0;
}

.logout-btn {
    display: inline-block;
    margin-top: 20px;
    color: #dc3545;
    text-decoration: none;
    font-weight: bold;
}
```

## فحص الاختراق باستخدام Kali Linux

تم استخدام أدوات Nmap و SQLMap لمحاكاة فحص الاختراق على التطبيق المطور.

### 1. فحص المنافذ باستخدام Nmap

تم استخدام Nmap لفحص المنافذ المفتوحة والخدمات العاملة على الخادم المحلي. أظهر الفحص أن خادم PHP المدمج يعمل على المنفذ 8080.

```text
Starting Nmap 7.80 ( https://nmap.org ) at 2026-02-03 17:47 EST
Nmap scan report for localhost (127.0.0.1)
Host is up (0.000073s latency).
Other addresses for localhost (not scanned): ::1
PORT     STATE SERVICE VERSION
8080/tcp open  http    PHP cli server 5.5 or later
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 6.30 seconds
```

### 2. فحص حقن SQL باستخدام SQLMap

تم استخدام SQLMap لاختبار صفحة تسجيل الدخول بحثًا عن ثغرات حقن SQL. أظهرت النتائج أن جميع المعاملات التي تم اختبارها (username, password) لا تبدو قابلة للحقن، مما يؤكد فعالية استخدام PDO والـ Prepared Statements في منع هذا النوع من الهجمات.

```text
[17:47:19] [INFO] testing 'Boolean-based blind - Parameter replace (original value)'
[17:47:19] [INFO] testing 'MySQL >= 5.1 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (EXTRACTVALUE)'
[17:47:19] [INFO] testing 'PostgreSQL AND error-based - WHERE or HAVING clause'
[17:47:19] [INFO] testing 'Microsoft SQL Server/Sybase AND error-based - WHERE or HAVING clause (IN)'
[17:47:19] [INFO] testing 'Oracle AND error-based - WHERE or HAVING clause (XMLType)'
[17:47:19] [INFO] testing 'Generic inline queries'
[17:47:19] [INFO] testing 'PostgreSQL > 8.1 stacked queries (comment)'
[17:47:19] [INFO] testing 'Microsoft SQL Server/Sybase stacked queries (comment)'
[17:47:19] [INFO] testing 'Oracle stacked queries (DBMS_PIPE.RECEIVE_MESSAGE - comment)'
[17:47:19] [INFO] testing 'MySQL >= 5.0.12 AND time-based blind (query SLEEP)'
[17:47:19] [INFO] testing 'PostgreSQL > 8.1 AND time-based blind'
[17:47:19] [INFO] testing 'Microsoft SQL Server/Sybase time-based blind (IF)'
[17:47:19] [INFO] testing 'Oracle AND time-based blind'
[17:47:19] [INFO] testing 'Generic UNION query (NULL) - 1 to 10 columns'
[17:47:19] [WARNING] POST parameter 'submit' does not seem to be injectable
[17:47:19] [CRITICAL] all tested parameters do not appear to be injectable. Try to increase values for '--level'/'--risk' options if you wish to perform more tests. If you suspect that there is some kind of protection mechanism involved (e.g. WAF) maybe you could try to use option '--tamper' (e.g. '--tamper=space2comment') and/or switch '--random-agent'
[17:47:19] [WARNING] your sqlmap version is outdated
[*] ending @ 17:47:19 /2026-02-03/
```

## الخلاصة

لقد تم بنجاح تطوير مشروع أمن ويب يلتزم بالمتطلبات المحددة، بما في ذلك استخدام PDO لتأمين الاتصال بقاعدة البيانات وتشفير كلمات المرور. أظهرت فحوصات الاختراق الأولية باستخدام Nmap و SQLMap أن التطبيق محمي بشكل جيد ضد هجمات حقن SQL الشائعة، مما يؤكد فعالية الممارسات الأمنية المطبقة. يمثل هذا المشروع أساسًا جيدًا لتطبيقات الويب الآمنة.
