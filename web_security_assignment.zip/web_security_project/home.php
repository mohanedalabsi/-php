<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الصفحة الرئيسية</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>مرحباً بك، <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p>لقد قمت بتسجيل الدخول بنجاح إلى نظام أمن الويب.</p>
        <div class="info-box">
            <h3>تفاصيل التكليف المنفذة:</h3>
            <ul>
                <li>استخدام <strong>PDO</strong> للاتصال بقاعدة البيانات.</li>
                <li>تشفير كلمات المرور باستخدام <strong>password_hash</strong>.</li>
                <li>حماية الجلسات (Sessions).</li>
                <li>منع هجمات SQL Injection عبر Prepared Statements.</li>
            </ul>
        </div>
        <a href="logout.php" class="logout-btn">تسجيل الخروج</a>
    </div>
</body>
</html>
